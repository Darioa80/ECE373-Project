package ships;
import base.*;

public class PTBoat extends Ship {
}
 