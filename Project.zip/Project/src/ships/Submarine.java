package ships;
import base.*;

public class Submarine extends Ship{
	public boolean Torpedo(){
		//FIXME
	}
	public boolean Sonar(){
		//FIXME
	}
}
