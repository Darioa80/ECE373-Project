package ships;

public class AirCraftCarrier extends Ship {
	private ArrayList<Plane> Planes = new Arraylist<Plane>;
	
	public boolean Exocet(){
		//FIXME
	}
}
